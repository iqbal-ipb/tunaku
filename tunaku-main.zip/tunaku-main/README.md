Coba Data Tuna
